import { useState, useCallback } from 'react';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useSymbol } from '@/hooks/useTradingData';
import TopNavigation from '@/components/trading/TopNavigation';
import ChartToolbar from '@/components/trading/ChartToolbar';
import TradingChart from '@/components/trading/TradingChart';
import WatchlistSidebar from '@/components/trading/WatchlistSidebar';
import MarketDepthPanel from '@/components/trading/MarketDepthPanel';
import TradingPanel from '@/components/trading/TradingPanel';
import OrderModal from '@/components/trading/OrderModal';
import IndicatorModal from '@/components/trading/IndicatorModal';
import { TimeFrame, ChartType, DrawingTool, WebSocketMessage } from '@/types/trading';
import { IndicatorConfig } from '@/lib/indicators';
import { formatPrice, formatPercentage } from '@/lib/tradingData';

export default function Trading() {
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSD');
  const [currentPrice, setCurrentPrice] = useState('43250.75');
  const [priceChange, setPriceChange] = useState('1.24');
  const [selectedTimeframe, setSelectedTimeframe] = useState<TimeFrame>('15m');
  const [selectedChartType, setSelectedChartType] = useState<ChartType>('candlestick');
  const [selectedDrawingTool, setSelectedDrawingTool] = useState<DrawingTool>(null);
  const [selectedLayout, setSelectedLayout] = useState('single');
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderModalSide, setOrderModalSide] = useState<'buy' | 'sell'>('buy');
  const [activeIndicators, setActiveIndicators] = useState<IndicatorConfig[]>([]);
  const [isIndicatorModalOpen, setIsIndicatorModalOpen] = useState(false);

  // Fetch current symbol data
  const { data: symbolData } = useSymbol(selectedSymbol);

  // WebSocket connection for real-time data
  useWebSocket({
    onMessage: useCallback((message: WebSocketMessage) => {
      switch (message.type) {
        case 'priceUpdate':
          if (message.data.symbol === selectedSymbol) {
            setCurrentPrice(parseFloat(message.data.price).toFixed(2));
            setPriceChange(parseFloat(message.data.change24h).toFixed(2));
          }
          break;
        case 'symbols':
          // Handle initial symbols data
          break;
        case 'newTrade':
          // Handle new trade data
          break;
        default:
          break;
      }
    }, [selectedSymbol]),
    onConnect: () => {
      console.log('Connected to trading WebSocket');
    },
    onDisconnect: () => {
      console.log('Disconnected from trading WebSocket');
    },
  });

  // Update current price and change from symbol data
  useState(() => {
    if (symbolData) {
      setCurrentPrice(parseFloat(symbolData.price).toFixed(2));
      setPriceChange(parseFloat(symbolData.change24h).toFixed(2));
    }
  });

  const handleSymbolSelect = (symbol: string) => {
    setSelectedSymbol(symbol);
  };

  const handleLayoutChange = (layout: string) => {
    setSelectedLayout(layout);
    // In a full implementation, this would change the chart layout
  };

  const handleTimeframeChange = (timeframe: TimeFrame) => {
    setSelectedTimeframe(timeframe);
  };

  const handleChartTypeChange = (type: ChartType) => {
    setSelectedChartType(type);
  };

  const handleDrawingToolChange = (tool: DrawingTool) => {
    setSelectedDrawingTool(tool);
  };

  const handleAddIndicator = () => {
    setIsIndicatorModalOpen(true);
  };

  const handleAddIndicatorConfig = (config: IndicatorConfig) => {
    setActiveIndicators(prev => [...prev, config]);
  };

  const handleUpdateIndicator = (config: IndicatorConfig) => {
    setActiveIndicators(prev => 
      prev.map(indicator => 
        indicator.id === config.id ? config : indicator
      )
    );
  };

  const handleRemoveIndicator = (id: string) => {
    setActiveIndicators(prev => prev.filter(indicator => indicator.id !== id));
  };

  const handleBuyClick = () => {
    setOrderModalSide('buy');
    setIsOrderModalOpen(true);
  };

  const handleSellClick = () => {
    setOrderModalSide('sell');
    setIsOrderModalOpen(true);
  };

  const handlePriceUpdate = (price: number) => {
    setCurrentPrice(price.toFixed(2));
  };

  const handleDepositClick = () => {
    console.log('Deposit clicked');
    // In a full implementation, this would open a deposit modal
  };

  const handleWithdrawClick = () => {
    console.log('Withdraw clicked');
    // In a full implementation, this would open a withdraw modal
  };

  return (
    <div className="min-h-screen bg-trading-bg text-trading-text overflow-hidden">
      {/* Top Navigation */}
      <TopNavigation
        currentSymbol={selectedSymbol}
        currentPrice={currentPrice}
        priceChange={priceChange}
        onSymbolSelect={handleSymbolSelect}
        onLayoutChange={handleLayoutChange}
      />

      <div className="flex h-screen" style={{ height: 'calc(100vh - 48px)' }}>
        {/* Left Sidebar - Watchlist */}
        <WatchlistSidebar
          onSymbolSelect={handleSymbolSelect}
          selectedSymbol={selectedSymbol}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col">
          {/* Chart Toolbar */}
          <ChartToolbar
            selectedTimeframe={selectedTimeframe}
            selectedChartType={selectedChartType}
            selectedDrawingTool={selectedDrawingTool}
            onTimeframeChange={handleTimeframeChange}
            onChartTypeChange={handleChartTypeChange}
            onDrawingToolChange={handleDrawingToolChange}
            onAddIndicator={handleAddIndicator}
            onBuyClick={handleBuyClick}
            onSellClick={handleSellClick}
          />

          {/* Chart Container */}
          <TradingChart
            symbol={selectedSymbol}
            timeframe={selectedTimeframe}
            chartType={selectedChartType}
            indicators={activeIndicators}
            onPriceUpdate={handlePriceUpdate}
          />
        </div>

        {/* Right Sidebar */}
        <MarketDepthPanel
          symbol={selectedSymbol}
          currentPrice={currentPrice}
        />
      </div>

      {/* Bottom Trading Panel */}
      <TradingPanel
        onDepositClick={handleDepositClick}
        onWithdrawClick={handleWithdrawClick}
      />

      {/* Order Modal */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        symbol={selectedSymbol}
        side={orderModalSide}
        currentPrice={currentPrice}
      />

      {/* Indicator Modal */}
      <IndicatorModal
        isOpen={isIndicatorModalOpen}
        onClose={() => setIsIndicatorModalOpen(false)}
        activeIndicators={activeIndicators}
        onAddIndicator={handleAddIndicatorConfig}
        onUpdateIndicator={handleUpdateIndicator}
        onRemoveIndicator={handleRemoveIndicator}
      />
    </div>
  );
}
