export interface TradingSymbol {
  id: string;
  symbol: string;
  name: string;
  type: 'crypto' | 'stock' | 'forex';
  price: string;
  change24h: string;
  volume24h: string;
  lastUpdated: Date;
}

export interface CandleData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface OrderBookEntry {
  price: string;
  quantity: string;
  total?: string;
}

export interface MarketDepthData {
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
}

export interface RecentTrade {
  id: string;
  symbol: string;
  price: string;
  quantity: string;
  side: 'buy' | 'sell';
  timestamp: Date;
}

export interface NewsItem {
  id: string;
  title: string;
  content: string;
  symbol?: string;
  publishedAt: Date;
  source: string;
}

export interface TradingOrder {
  id: string;
  symbol: string;
  side: 'buy' | 'sell';
  type: 'market' | 'limit' | 'stop' | 'stop-limit';
  quantity: string;
  price?: string;
  status: 'pending' | 'filled' | 'cancelled';
  createdAt: Date;
}

export interface Position {
  id: string;
  symbol: string;
  quantity: string;
  averagePrice: string;
  unrealizedPnl: string;
  lastUpdated: Date;
}

export interface AccountData {
  balance: string;
  equity: string;
  freeMargin: string;
  marginLevel: string;
  pnl: string;
  todayPnl: string;
}

export type TimeFrame = '1m' | '5m' | '15m' | '1h' | '4h' | '1d' | '1w';

export type ChartType = 'candlestick' | 'line' | 'area';

export type DrawingTool = 'trendline' | 'horizontal' | 'rectangle' | 'fibonacci' | null;

export interface WatchlistItem {
  symbol: string;
  name: string;
  price: string;
  changePercent: string;
  changeValue: string;
}

export interface WebSocketMessage {
  type: string;
  data: any;
}
