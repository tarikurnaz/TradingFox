import { CandleData } from '@/types/trading';

export interface IndicatorData {
  time: number;
  value: number;
  color?: string;
}

export interface IndicatorConfig {
  id: string;
  type: IndicatorType;
  name: string;
  visible: boolean;
  parameters: { [key: string]: any };
  style: {
    color: string;
    lineWidth: number;
    lineStyle: 'solid' | 'dashed' | 'dotted';
  };
}

export type IndicatorType = 
  | 'SMA'    // Simple Moving Average
  | 'EMA'    // Exponential Moving Average
  | 'RSI'    // Relative Strength Index
  | 'MACD'   // Moving Average Convergence Divergence
  | 'BB'     // Bollinger Bands
  | 'STOCH'  // Stochastic Oscillator
  | 'ATR'    // Average True Range
  | 'VOLUME' // Volume
  | 'OBV'    // On Balance Volume
  | 'WILLIAMS' // Williams %R
  | 'CCI';   // Commodity Channel Index

// Simple Moving Average
export function calculateSMA(data: CandleData[], period: number = 20): IndicatorData[] {
  const result: IndicatorData[] = [];
  
  for (let i = period - 1; i < data.length; i++) {
    const sum = data.slice(i - period + 1, i + 1).reduce((acc, candle) => acc + candle.close, 0);
    const average = sum / period;
    
    result.push({
      time: data[i].time,
      value: average,
    });
  }
  
  return result;
}

// Exponential Moving Average
export function calculateEMA(data: CandleData[], period: number = 20): IndicatorData[] {
  const result: IndicatorData[] = [];
  const multiplier = 2 / (period + 1);
  
  if (data.length === 0) return result;
  
  // First EMA is just SMA
  let ema = data.slice(0, period).reduce((acc, candle) => acc + candle.close, 0) / period;
  result.push({
    time: data[period - 1].time,
    value: ema,
  });
  
  // Calculate subsequent EMAs
  for (let i = period; i < data.length; i++) {
    ema = (data[i].close * multiplier) + (ema * (1 - multiplier));
    result.push({
      time: data[i].time,
      value: ema,
    });
  }
  
  return result;
}

// Relative Strength Index
export function calculateRSI(data: CandleData[], period: number = 14): IndicatorData[] {
  const result: IndicatorData[] = [];
  const gains: number[] = [];
  const losses: number[] = [];
  
  // Calculate price changes
  for (let i = 1; i < data.length; i++) {
    const change = data[i].close - data[i - 1].close;
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? Math.abs(change) : 0);
  }
  
  // Calculate RSI
  for (let i = period - 1; i < gains.length; i++) {
    const avgGain = gains.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
    const avgLoss = losses.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
    
    const rs = avgGain / (avgLoss || 1);
    const rsi = 100 - (100 / (1 + rs));
    
    result.push({
      time: data[i + 1].time,
      value: rsi,
    });
  }
  
  return result;
}

// MACD (Moving Average Convergence Divergence)
export function calculateMACD(
  data: CandleData[], 
  fastPeriod: number = 12, 
  slowPeriod: number = 26, 
  signalPeriod: number = 9
): { macd: IndicatorData[]; signal: IndicatorData[]; histogram: IndicatorData[] } {
  const fastEMA = calculateEMA(data, fastPeriod);
  const slowEMA = calculateEMA(data, slowPeriod);
  
  const macdLine: IndicatorData[] = [];
  const minLength = Math.min(fastEMA.length, slowEMA.length);
  
  // Calculate MACD line
  for (let i = 0; i < minLength; i++) {
    if (fastEMA[i].time === slowEMA[i].time) {
      macdLine.push({
        time: fastEMA[i].time,
        value: fastEMA[i].value - slowEMA[i].value,
      });
    }
  }
  
  // Calculate signal line (EMA of MACD)
  const signalLine = calculateEMA(macdLine.map(point => ({
    time: point.time,
    open: point.value,
    high: point.value,
    low: point.value,
    close: point.value,
    volume: 0,
  })), signalPeriod);
  
  // Calculate histogram
  const histogram: IndicatorData[] = [];
  const histogramLength = Math.min(macdLine.length, signalLine.length);
  
  for (let i = 0; i < histogramLength; i++) {
    if (macdLine[i].time === signalLine[i].time) {
      histogram.push({
        time: macdLine[i].time,
        value: macdLine[i].value - signalLine[i].value,
      });
    }
  }
  
  return {
    macd: macdLine,
    signal: signalLine,
    histogram,
  };
}

// Bollinger Bands
export function calculateBollingerBands(
  data: CandleData[], 
  period: number = 20, 
  multiplier: number = 2
): { upper: IndicatorData[]; middle: IndicatorData[]; lower: IndicatorData[] } {
  const sma = calculateSMA(data, period);
  const upper: IndicatorData[] = [];
  const lower: IndicatorData[] = [];
  
  for (let i = 0; i < sma.length; i++) {
    const dataIndex = i + period - 1;
    const slice = data.slice(dataIndex - period + 1, dataIndex + 1);
    
    // Calculate standard deviation
    const variance = slice.reduce((acc, candle) => {
      const diff = candle.close - sma[i].value;
      return acc + (diff * diff);
    }, 0) / period;
    
    const stdDev = Math.sqrt(variance);
    
    upper.push({
      time: sma[i].time,
      value: sma[i].value + (stdDev * multiplier),
    });
    
    lower.push({
      time: sma[i].time,
      value: sma[i].value - (stdDev * multiplier),
    });
  }
  
  return {
    upper,
    middle: sma,
    lower,
  };
}

// Stochastic Oscillator
export function calculateStochastic(
  data: CandleData[], 
  kPeriod: number = 14, 
  dPeriod: number = 3
): { k: IndicatorData[]; d: IndicatorData[] } {
  const kValues: IndicatorData[] = [];
  
  // Calculate %K
  for (let i = kPeriod - 1; i < data.length; i++) {
    const slice = data.slice(i - kPeriod + 1, i + 1);
    const highest = Math.max(...slice.map(candle => candle.high));
    const lowest = Math.min(...slice.map(candle => candle.low));
    const current = data[i].close;
    
    const k = ((current - lowest) / (highest - lowest)) * 100;
    
    kValues.push({
      time: data[i].time,
      value: k,
    });
  }
  
  // Calculate %D (SMA of %K)
  const dValues: IndicatorData[] = [];
  
  for (let i = dPeriod - 1; i < kValues.length; i++) {
    const sum = kValues.slice(i - dPeriod + 1, i + 1).reduce((acc, val) => acc + val.value, 0);
    const average = sum / dPeriod;
    
    dValues.push({
      time: kValues[i].time,
      value: average,
    });
  }
  
  return {
    k: kValues,
    d: dValues,
  };
}

// Volume Indicator
export function calculateVolume(data: CandleData[]): IndicatorData[] {
  return data.map(candle => ({
    time: candle.time,
    value: candle.volume || 0,
    color: candle.close >= candle.open ? '#00C896' : '#FF4747',
  }));
}

// Average True Range
export function calculateATR(data: CandleData[], period: number = 14): IndicatorData[] {
  const trueRanges: number[] = [];
  
  // Calculate True Range for each period
  for (let i = 1; i < data.length; i++) {
    const current = data[i];
    const previous = data[i - 1];
    
    const tr1 = current.high - current.low;
    const tr2 = Math.abs(current.high - previous.close);
    const tr3 = Math.abs(current.low - previous.close);
    
    trueRanges.push(Math.max(tr1, tr2, tr3));
  }
  
  // Calculate ATR using SMA of True Ranges
  const result: IndicatorData[] = [];
  
  for (let i = period - 1; i < trueRanges.length; i++) {
    const sum = trueRanges.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    const atr = sum / period;
    
    result.push({
      time: data[i + 1].time,
      value: atr,
    });
  }
  
  return result;
}

// Williams %R
export function calculateWilliamsR(data: CandleData[], period: number = 14): IndicatorData[] {
  const result: IndicatorData[] = [];
  
  for (let i = period - 1; i < data.length; i++) {
    const slice = data.slice(i - period + 1, i + 1);
    const highest = Math.max(...slice.map(candle => candle.high));
    const lowest = Math.min(...slice.map(candle => candle.low));
    const current = data[i].close;
    
    const williamsR = ((highest - current) / (highest - lowest)) * -100;
    
    result.push({
      time: data[i].time,
      value: williamsR,
    });
  }
  
  return result;
}

// Commodity Channel Index
export function calculateCCI(data: CandleData[], period: number = 20): IndicatorData[] {
  const result: IndicatorData[] = [];
  const constant = 0.015;
  
  for (let i = period - 1; i < data.length; i++) {
    const slice = data.slice(i - period + 1, i + 1);
    
    // Calculate typical prices
    const typicalPrices = slice.map(candle => (candle.high + candle.low + candle.close) / 3);
    
    // Calculate SMA of typical prices
    const smaTP = typicalPrices.reduce((a, b) => a + b, 0) / period;
    
    // Calculate mean deviation
    const meanDeviation = typicalPrices.reduce((acc, tp) => acc + Math.abs(tp - smaTP), 0) / period;
    
    // Calculate CCI
    const currentTP = (data[i].high + data[i].low + data[i].close) / 3;
    const cci = (currentTP - smaTP) / (constant * meanDeviation);
    
    result.push({
      time: data[i].time,
      value: cci,
    });
  }
  
  return result;
}

// Default indicator configurations
export const defaultIndicatorConfigs: Record<IndicatorType, Omit<IndicatorConfig, 'id'>> = {
  SMA: {
    type: 'SMA',
    name: 'Simple Moving Average',
    visible: true,
    parameters: { period: 20 },
    style: { color: '#2962FF', lineWidth: 2, lineStyle: 'solid' },
  },
  EMA: {
    type: 'EMA',
    name: 'Exponential Moving Average',
    visible: true,
    parameters: { period: 20 },
    style: { color: '#FF6D00', lineWidth: 2, lineStyle: 'solid' },
  },
  RSI: {
    type: 'RSI',
    name: 'RSI (14)',
    visible: true,
    parameters: { period: 14 },
    style: { color: '#9C27B0', lineWidth: 2, lineStyle: 'solid' },
  },
  MACD: {
    type: 'MACD',
    name: 'MACD (12,26,9)',
    visible: true,
    parameters: { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
    style: { color: '#4CAF50', lineWidth: 2, lineStyle: 'solid' },
  },
  BB: {
    type: 'BB',
    name: 'Bollinger Bands (20,2)',
    visible: true,
    parameters: { period: 20, multiplier: 2 },
    style: { color: '#FF5722', lineWidth: 1, lineStyle: 'solid' },
  },
  STOCH: {
    type: 'STOCH',
    name: 'Stochastic (14,3)',
    visible: true,
    parameters: { kPeriod: 14, dPeriod: 3 },
    style: { color: '#795548', lineWidth: 2, lineStyle: 'solid' },
  },
  ATR: {
    type: 'ATR',
    name: 'Average True Range (14)',
    visible: true,
    parameters: { period: 14 },
    style: { color: '#607D8B', lineWidth: 2, lineStyle: 'solid' },
  },
  VOLUME: {
    type: 'VOLUME',
    name: 'Volume',
    visible: true,
    parameters: {},
    style: { color: '#9E9E9E', lineWidth: 1, lineStyle: 'solid' },
  },
  OBV: {
    type: 'OBV',
    name: 'On Balance Volume',
    visible: true,
    parameters: {},
    style: { color: '#3F51B5', lineWidth: 2, lineStyle: 'solid' },
  },
  WILLIAMS: {
    type: 'WILLIAMS',
    name: 'Williams %R (14)',
    visible: true,
    parameters: { period: 14 },
    style: { color: '#E91E63', lineWidth: 2, lineStyle: 'solid' },
  },
  CCI: {
    type: 'CCI',
    name: 'Commodity Channel Index (20)',
    visible: true,
    parameters: { period: 20 },
    style: { color: '#00BCD4', lineWidth: 2, lineStyle: 'solid' },
  },
};

// Calculate indicator data based on type
export function calculateIndicator(
  type: IndicatorType,
  data: CandleData[],
  parameters: { [key: string]: any }
): any {
  switch (type) {
    case 'SMA':
      return calculateSMA(data, parameters.period || 20);
    case 'EMA':
      return calculateEMA(data, parameters.period || 20);
    case 'RSI':
      return calculateRSI(data, parameters.period || 14);
    case 'MACD':
      return calculateMACD(
        data,
        parameters.fastPeriod || 12,
        parameters.slowPeriod || 26,
        parameters.signalPeriod || 9
      );
    case 'BB':
      return calculateBollingerBands(data, parameters.period || 20, parameters.multiplier || 2);
    case 'STOCH':
      return calculateStochastic(data, parameters.kPeriod || 14, parameters.dPeriod || 3);
    case 'ATR':
      return calculateATR(data, parameters.period || 14);
    case 'VOLUME':
      return calculateVolume(data);
    case 'WILLIAMS':
      return calculateWilliamsR(data, parameters.period || 14);
    case 'CCI':
      return calculateCCI(data, parameters.period || 20);
    default:
      return [];
  }
}