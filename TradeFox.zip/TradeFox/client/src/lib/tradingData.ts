import { CandleData, TimeFrame } from "@/types/trading";

export function convertCandleData(candles: any[]): CandleData[] {
  return candles.map(candle => ({
    time: Math.floor(new Date(candle.timestamp).getTime() / 1000),
    open: parseFloat(candle.open),
    high: parseFloat(candle.high),
    low: parseFloat(candle.low),
    close: parseFloat(candle.close),
    volume: parseFloat(candle.volume),
  }));
}

export function formatPrice(price: string | number, decimals = 2): string {
  const num = typeof price === 'string' ? parseFloat(price) : price;
  return num.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatPercentage(value: string | number): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  const sign = num >= 0 ? '+' : '';
  return `${sign}${num.toFixed(2)}%`;
}

export function formatVolume(volume: string | number): string {
  const num = typeof volume === 'string' ? parseFloat(volume) : volume;
  
  if (num >= 1e9) {
    return `${(num / 1e9).toFixed(2)}B`;
  } else if (num >= 1e6) {
    return `${(num / 1e6).toFixed(2)}M`;
  } else if (num >= 1e3) {
    return `${(num / 1e3).toFixed(2)}K`;
  }
  
  return num.toFixed(2);
}

export function formatTime(timestamp: Date | string): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString('en-US', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

export function formatTimeAgo(timestamp: Date | string): string {
  const now = new Date();
  const date = new Date(timestamp);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  
  if (diffMins < 1) {
    return 'Just now';
  } else if (diffMins < 60) {
    return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  } else if (diffMins < 1440) {
    const hours = Math.floor(diffMins / 60);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else {
    const days = Math.floor(diffMins / 1440);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }
}

export function getTimeFrameLabel(timeframe: TimeFrame): string {
  const labels: Record<TimeFrame, string> = {
    '1m': '1 Minute',
    '5m': '5 Minutes',
    '15m': '15 Minutes',
    '1h': '1 Hour',
    '4h': '4 Hours',
    '1d': '1 Day',
    '1w': '1 Week',
  };
  
  return labels[timeframe] || timeframe;
}

export function getPriceChangeColor(change: string | number): string {
  const num = typeof change === 'string' ? parseFloat(change) : change;
  if (num > 0) return 'text-trading-buy';
  if (num < 0) return 'text-trading-sell';
  return 'text-trading-text';
}

export function calculatePnL(quantity: string, averagePrice: string, currentPrice: string): number {
  const qty = parseFloat(quantity);
  const avgPrice = parseFloat(averagePrice);
  const curPrice = parseFloat(currentPrice);
  
  return (curPrice - avgPrice) * qty;
}

export function validateSymbol(symbol: string): boolean {
  return /^[A-Z]{2,10}(USD|EUR|BTC|ETH)?$/i.test(symbol);
}

export function validatePrice(price: string): boolean {
  const num = parseFloat(price);
  return !isNaN(num) && num > 0;
}

export function validateQuantity(quantity: string): boolean {
  const num = parseFloat(quantity);
  return !isNaN(num) && num > 0;
}
