import { useState } from 'react';
import { Search, TrendingUp, Grid, Columns, Grid3X3, ChevronDown, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface TopNavigationProps {
  currentSymbol: string;
  currentPrice: string;
  priceChange: string;
  onSymbolSelect: (symbol: string) => void;
  onLayoutChange: (layout: string) => void;
}

export default function TopNavigation({
  currentSymbol,
  currentPrice,
  priceChange,
  onSymbolSelect,
  onLayoutChange,
}: TopNavigationProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLayout, setSelectedLayout] = useState('single');

  const handleLayoutSelect = (layout: string) => {
    setSelectedLayout(layout);
    onLayoutChange(layout);
  };

  const isPricePositive = parseFloat(priceChange) >= 0;

  return (
    <nav className="bg-trading-panel border-b border-trading-border h-12 flex items-center px-4 relative z-50">
      <div className="flex items-center space-x-6">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <TrendingUp className="text-white w-4 h-4" />
          </div>
          <span className="text-lg font-bold text-white">TradingFox</span>
        </div>
        
        {/* Symbol Search */}
        <div className="relative">
          <Input
            type="text"
            placeholder="Search symbols..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-trading-bg border-trading-border w-48 h-8 text-sm focus:border-trading-accent"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-trading-text-secondary w-3 h-3" />
        </div>
        
        {/* Current Symbol Info */}
        <div className="flex items-center space-x-4 text-sm">
          <span className="font-semibold text-white">{currentSymbol}</span>
          <span className={`font-bold ${isPricePositive ? 'text-trading-buy' : 'text-trading-sell'}`}>
            ${currentPrice}
          </span>
          <Badge
            variant="outline"
            className={`text-xs border-0 ${
              isPricePositive 
                ? 'bg-trading-buy bg-opacity-10 text-trading-buy' 
                : 'bg-trading-sell bg-opacity-10 text-trading-sell'
            }`}
          >
            {isPricePositive ? '+' : ''}{priceChange}%
          </Badge>
        </div>
      </div>
      
      {/* Right Side Controls */}
      <div className="ml-auto flex items-center space-x-4">
        {/* Layout Selector */}
        <div className="flex items-center space-x-1 bg-trading-bg rounded p-1">
          <Button
            size="sm"
            variant="ghost"
            className={`w-6 h-6 p-0 ${selectedLayout === 'single' ? 'bg-trading-accent text-white' : 'hover:bg-trading-border text-trading-text'}`}
            onClick={() => handleLayoutSelect('single')}
          >
            <Grid className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={`w-6 h-6 p-0 ${selectedLayout === 'dual' ? 'bg-trading-accent text-white' : 'hover:bg-trading-border text-trading-text'}`}
            onClick={() => handleLayoutSelect('dual')}
          >
            <Columns className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={`w-6 h-6 p-0 ${selectedLayout === 'quad' ? 'bg-trading-accent text-white' : 'hover:bg-trading-border text-trading-text'}`}
            onClick={() => handleLayoutSelect('quad')}
          >
            <Grid3X3 className="w-3 h-3" />
          </Button>
        </div>
        
        {/* User Menu */}
        <div className="flex items-center space-x-2 cursor-pointer">
          <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center">
            <User className="text-white w-4 h-4" />
          </div>
          <ChevronDown className="text-trading-text-secondary w-3 h-3" />
        </div>
      </div>
    </nav>
  );
}
