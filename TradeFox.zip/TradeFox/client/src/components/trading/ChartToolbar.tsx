import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart, 
  TrendingUp, 
  Minus, 
  Square, 
  Waves, 
  Plus,
  Activity,
  Settings
} from 'lucide-react';
import { TimeFrame, ChartType, DrawingTool } from '@/types/trading';

interface ChartToolbarProps {
  selectedTimeframe: TimeFrame;
  selectedChartType: ChartType;
  selectedDrawingTool: DrawingTool;
  onTimeframeChange: (timeframe: TimeFrame) => void;
  onChartTypeChange: (type: ChartType) => void;
  onDrawingToolChange: (tool: DrawingTool) => void;
  onAddIndicator: () => void;
  onBuyClick: () => void;
  onSellClick: () => void;
}

const timeframes: TimeFrame[] = ['1m', '5m', '15m', '1h', '4h', '1d', '1w'];

export default function ChartToolbar({
  selectedTimeframe,
  selectedChartType,
  selectedDrawingTool,
  onTimeframeChange,
  onChartTypeChange,
  onDrawingToolChange,
  onAddIndicator,
  onBuyClick,
  onSellClick,
}: ChartToolbarProps) {
  return (
    <div className="bg-trading-panel border-b border-trading-border p-2 flex items-center space-x-4">
      {/* Timeframe Selector */}
      <div className="flex items-center space-x-1 bg-trading-bg rounded p-1">
        {timeframes.map((timeframe) => (
          <Button
            key={timeframe}
            size="sm"
            variant="ghost"
            className={`px-2 py-1 text-xs h-6 ${
              selectedTimeframe === timeframe
                ? 'bg-trading-accent text-white'
                : 'hover:bg-trading-border text-trading-text'
            }`}
            onClick={() => onTimeframeChange(timeframe)}
          >
            {timeframe}
          </Button>
        ))}
      </div>
      
      {/* Chart Type */}
      <div className="flex items-center space-x-1">
        <Button
          size="sm"
          variant="ghost"
          className={`p-1 h-6 w-6 ${
            selectedChartType === 'candlestick' 
              ? 'text-white' 
              : 'text-trading-text-secondary hover:text-trading-text'
          }`}
          onClick={() => onChartTypeChange('candlestick')}
          title="Candlestick"
        >
          <BarChart className="w-3 h-3" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className={`p-1 h-6 w-6 ${
            selectedChartType === 'line' 
              ? 'text-white' 
              : 'text-trading-text-secondary hover:text-trading-text'
          }`}
          onClick={() => onChartTypeChange('line')}
          title="Line Chart"
        >
          <TrendingUp className="w-3 h-3" />
        </Button>
      </div>
      
      {/* Drawing Tools */}
      <div className="flex items-center space-x-1 border-l border-trading-border pl-4">
        <Button
          size="sm"
          variant="ghost"
          className={`p-1 h-6 w-6 ${
            selectedDrawingTool === 'trendline' 
              ? 'bg-trading-accent text-white' 
              : 'hover:bg-trading-border text-trading-text'
          }`}
          onClick={() => onDrawingToolChange(selectedDrawingTool === 'trendline' ? null : 'trendline')}
          title="Trend Line"
        >
          <Activity className="w-3 h-3 rotate-45" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className={`p-1 h-6 w-6 ${
            selectedDrawingTool === 'horizontal' 
              ? 'bg-trading-accent text-white' 
              : 'hover:bg-trading-border text-trading-text'
          }`}
          onClick={() => onDrawingToolChange(selectedDrawingTool === 'horizontal' ? null : 'horizontal')}
          title="Horizontal Line"
        >
          <Minus className="w-3 h-3" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className={`p-1 h-6 w-6 ${
            selectedDrawingTool === 'rectangle' 
              ? 'bg-trading-accent text-white' 
              : 'hover:bg-trading-border text-trading-text'
          }`}
          onClick={() => onDrawingToolChange(selectedDrawingTool === 'rectangle' ? null : 'rectangle')}
          title="Rectangle"
        >
          <Square className="w-3 h-3" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className={`p-1 h-6 w-6 ${
            selectedDrawingTool === 'fibonacci' 
              ? 'bg-trading-accent text-white' 
              : 'hover:bg-trading-border text-trading-text'
          }`}
          onClick={() => onDrawingToolChange(selectedDrawingTool === 'fibonacci' ? null : 'fibonacci')}
          title="Fibonacci"
        >
          <Waves className="w-3 h-3" />
        </Button>
      </div>
      
      {/* Indicators */}
      <div className="flex items-center space-x-1 border-l border-trading-border pl-4">
        <Button
          size="sm"
          variant="ghost"
          className="px-2 py-1 text-xs bg-trading-bg hover:bg-trading-border rounded h-6"
          onClick={onAddIndicator}
          title="Technical Indicators"
        >
          <Settings className="w-3 h-3 mr-1" />
          Indicators
        </Button>
      </div>
      
      {/* Buy/Sell Buttons */}
      <div className="ml-auto flex items-center space-x-2">
        <Button
          className="px-4 py-1.5 bg-trading-buy hover:bg-trading-buy hover:opacity-80 text-white text-sm font-medium h-7"
          onClick={onBuyClick}
        >
          BUY
        </Button>
        <Button
          className="px-4 py-1.5 bg-trading-sell hover:bg-trading-sell hover:opacity-80 text-white text-sm font-medium h-7"
          onClick={onSellClick}
        >
          SELL
        </Button>
      </div>
    </div>
  );
}
