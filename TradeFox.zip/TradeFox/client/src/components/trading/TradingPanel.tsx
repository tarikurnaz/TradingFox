import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useOrders, usePositions, useAccountData } from '@/hooks/useTradingData';
import { formatPrice, formatTimeAgo, getPriceChangeColor } from '@/lib/tradingData';
import { Plus, Minus, FileText, Loader2 } from 'lucide-react';

interface TradingPanelProps {
  onDepositClick: () => void;
  onWithdrawClick: () => void;
}

export default function TradingPanel({ onDepositClick, onWithdrawClick }: TradingPanelProps) {
  const [activeTab, setActiveTab] = useState<'account' | 'orders' | 'positions' | 'history'>('account');
  
  const { data: orders, isLoading: isOrdersLoading } = useOrders();
  const { data: positions, isLoading: isPositionsLoading } = usePositions();
  const { data: accountData } = useAccountData();

  const renderTabContent = () => {
    switch (activeTab) {
      case 'account':
        return (
          <div className="p-4">
            <div className="grid grid-cols-6 gap-6 mb-4">
              <div className="text-center">
                <div className="text-xs text-trading-text-secondary mb-1">Balance</div>
                <div className="text-lg font-bold text-white">${accountData?.balance}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-trading-text-secondary mb-1">Equity</div>
                <div className="text-lg font-bold text-white">${accountData?.equity}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-trading-text-secondary mb-1">Free Margin</div>
                <div className="text-lg font-bold text-white">${accountData?.freeMargin}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-trading-text-secondary mb-1">Margin Level</div>
                <div className="text-lg font-bold text-trading-buy">{accountData?.marginLevel}%</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-trading-text-secondary mb-1">P&L</div>
                <div className="text-lg font-bold text-trading-buy">${accountData?.pnl}</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-trading-text-secondary mb-1">Today's P&L</div>
                <div className="text-lg font-bold text-trading-buy">${accountData?.todayPnl}</div>
              </div>
            </div>
            
            {/* Quick Actions */}
            <div className="flex items-center space-x-4">
              <Button
                className="bg-trading-accent hover:bg-trading-accent hover:opacity-80 text-white"
                onClick={onDepositClick}
              >
                <Plus className="w-4 h-4 mr-2" />
                Deposit
              </Button>
              <Button
                variant="outline"
                className="border-trading-border hover:bg-trading-border text-trading-text"
                onClick={onWithdrawClick}
              >
                <Minus className="w-4 h-4 mr-2" />
                Withdraw
              </Button>
              <Button
                variant="outline"
                className="border-trading-border hover:bg-trading-border text-trading-text"
              >
                <FileText className="w-4 h-4 mr-2" />
                Statement
              </Button>
            </div>
          </div>
        );

      case 'orders':
        return (
          <div className="p-4">
            {isOrdersLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-trading-text-secondary" />
              </div>
            ) : orders && orders.length > 0 ? (
              <div className="space-y-2">
                <div className="grid grid-cols-6 gap-4 text-xs font-semibold text-trading-text-secondary pb-2 border-b border-trading-border">
                  <div>Symbol</div>
                  <div>Side</div>
                  <div>Type</div>
                  <div>Quantity</div>
                  <div>Price</div>
                  <div>Status</div>
                </div>
                {orders.map((order) => (
                  <div key={order.id} className="grid grid-cols-6 gap-4 text-xs py-2 border-b border-trading-border">
                    <div className="font-medium text-white">{order.symbol}</div>
                    <div className={order.side === 'buy' ? 'text-trading-buy' : 'text-trading-sell'}>
                      {order.side.toUpperCase()}
                    </div>
                    <div className="text-trading-text">{order.type}</div>
                    <div className="text-trading-text">{formatPrice(order.quantity, 5)}</div>
                    <div className="text-trading-text">{order.price ? `$${formatPrice(order.price, 2)}` : 'Market'}</div>
                    <div>
                      <Badge
                        variant="outline"
                        className={`text-xs border-0 ${
                          order.status === 'filled' 
                            ? 'bg-trading-buy bg-opacity-10 text-trading-buy'
                            : order.status === 'cancelled'
                            ? 'bg-trading-sell bg-opacity-10 text-trading-sell'
                            : 'bg-trading-accent bg-opacity-10 text-trading-accent'
                        }`}
                      >
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-trading-text-secondary">
                No active orders
              </div>
            )}
          </div>
        );

      case 'positions':
        return (
          <div className="p-4">
            {isPositionsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-trading-text-secondary" />
              </div>
            ) : positions && positions.length > 0 ? (
              <div className="space-y-2">
                <div className="grid grid-cols-5 gap-4 text-xs font-semibold text-trading-text-secondary pb-2 border-b border-trading-border">
                  <div>Symbol</div>
                  <div>Quantity</div>
                  <div>Avg Price</div>
                  <div>Current P&L</div>
                  <div>Last Updated</div>
                </div>
                {positions.map((position) => (
                  <div key={position.id} className="grid grid-cols-5 gap-4 text-xs py-2 border-b border-trading-border">
                    <div className="font-medium text-white">{position.symbol}</div>
                    <div className="text-trading-text">{formatPrice(position.quantity, 5)}</div>
                    <div className="text-trading-text">${formatPrice(position.averagePrice, 2)}</div>
                    <div className={getPriceChangeColor(position.unrealizedPnl)}>
                      ${formatPrice(position.unrealizedPnl, 2)}
                    </div>
                    <div className="text-trading-text-secondary">{formatTimeAgo(position.lastUpdated)}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-trading-text-secondary">
                No open positions
              </div>
            )}
          </div>
        );

      case 'history':
        return (
          <div className="p-4">
            <div className="text-center py-8 text-trading-text-secondary">
              No trading history available
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="bg-trading-panel border-t border-trading-border" style={{ height: '280px' }}>
      {/* Panel Tabs */}
      <div className="flex border-b border-trading-border">
        {(['account', 'orders', 'positions', 'history'] as const).map((tab) => (
          <Button
            key={tab}
            variant="ghost"
            className={`px-4 py-2 text-sm font-medium rounded-none border-b-2 ${
              activeTab === tab
                ? 'bg-trading-accent text-white border-trading-accent'
                : 'hover:bg-trading-bg text-trading-text border-transparent'
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </Button>
        ))}
      </div>
      
      {/* Tab Content */}
      <div className="overflow-y-auto" style={{ height: 'calc(280px - 41px)' }}>
        {renderTabContent()}
      </div>
    </div>
  );
}
