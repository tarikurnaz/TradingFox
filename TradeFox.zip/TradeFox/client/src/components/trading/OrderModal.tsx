import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { validatePrice, validateQuantity } from '@/lib/tradingData';
import { X } from 'lucide-react';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
  side?: 'buy' | 'sell';
  currentPrice: string;
}

interface OrderFormData {
  symbol: string;
  side: 'buy' | 'sell';
  type: 'market' | 'limit' | 'stop' | 'stop-limit';
  quantity: string;
  price: string;
}

export default function OrderModal({ 
  isOpen, 
  onClose, 
  symbol, 
  side = 'buy',
  currentPrice 
}: OrderModalProps) {
  const [formData, setFormData] = useState<OrderFormData>({
    symbol,
    side,
    type: 'market',
    quantity: '',
    price: currentPrice,
  });
  const [errors, setErrors] = useState<Partial<OrderFormData>>({});

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const orderMutation = useMutation({
    mutationFn: async (orderData: Omit<OrderFormData, 'symbol'> & { symbol: string }) => {
      const response = await apiRequest('POST', '/api/orders', orderData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Order Placed',
        description: `${formData.side.toUpperCase()} order for ${formData.quantity} ${formData.symbol} has been placed successfully.`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/positions'] });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: 'Order Failed',
        description: error.message || 'Failed to place order. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const resetForm = () => {
    setFormData({
      symbol,
      side: 'buy',
      type: 'market',
      quantity: '',
      price: currentPrice,
    });
    setErrors({});
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<OrderFormData> = {};

    if (!formData.quantity.trim()) {
      newErrors.quantity = 'Quantity is required';
    } else if (!validateQuantity(formData.quantity)) {
      newErrors.quantity = 'Invalid quantity';
    }

    if (formData.type === 'limit' || formData.type === 'stop' || formData.type === 'stop-limit') {
      if (!formData.price.trim()) {
        newErrors.price = 'Price is required for this order type';
      } else if (!validatePrice(formData.price)) {
        newErrors.price = 'Invalid price';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const orderData = {
      ...formData,
      userId: 'demo-user', // In real app, get from auth context
    };

    orderMutation.mutate(orderData);
  };

  const handleClose = () => {
    if (!orderMutation.isPending) {
      onClose();
      resetForm();
    }
  };

  const calculateTotal = () => {
    if (!formData.quantity || !formData.price) return '0.00';
    const quantity = parseFloat(formData.quantity);
    const price = formData.type === 'market' ? parseFloat(currentPrice) : parseFloat(formData.price);
    return (quantity * price).toFixed(2);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-trading-panel border-trading-border w-96 p-0">
        <DialogHeader className="p-6 pb-4">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold text-white">Place Order</DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              className="p-1 h-6 w-6 text-trading-text-secondary hover:text-trading-text"
              onClick={handleClose}
              disabled={orderMutation.isPending}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="px-6 pb-6 space-y-4">
          {/* Buy/Sell Toggle */}
          <div className="flex space-x-2">
            <Button
              type="button"
              className={`flex-1 py-2 font-medium ${
                formData.side === 'buy'
                  ? 'bg-trading-buy text-white'
                  : 'bg-trading-border text-trading-text hover:bg-trading-border'
              }`}
              onClick={() => setFormData(prev => ({ ...prev, side: 'buy' }))}
              disabled={orderMutation.isPending}
            >
              BUY
            </Button>
            <Button
              type="button"
              className={`flex-1 py-2 font-medium ${
                formData.side === 'sell'
                  ? 'bg-trading-sell text-white'
                  : 'bg-trading-border text-trading-text hover:bg-trading-border'
              }`}
              onClick={() => setFormData(prev => ({ ...prev, side: 'sell' }))}
              disabled={orderMutation.isPending}
            >
              SELL
            </Button>
          </div>

          {/* Symbol */}
          <div>
            <Label className="text-sm text-trading-text-secondary">Symbol</Label>
            <Input
              value={formData.symbol}
              className="bg-trading-bg border-trading-border text-white mt-1"
              readOnly
            />
          </div>

          {/* Quantity and Price */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm text-trading-text-secondary">Quantity</Label>
              <Input
                type="number"
                step="0.00001"
                placeholder="0.001"
                value={formData.quantity}
                onChange={(e) => setFormData(prev => ({ ...prev, quantity: e.target.value }))}
                className={`bg-trading-bg border-trading-border text-white mt-1 ${
                  errors.quantity ? 'border-trading-sell' : ''
                }`}
                disabled={orderMutation.isPending}
              />
              {errors.quantity && (
                <p className="text-xs text-trading-sell mt-1">{errors.quantity}</p>
              )}
            </div>
            <div>
              <Label className="text-sm text-trading-text-secondary">
                Price {formData.type === 'market' && '(Market)'}
              </Label>
              <Input
                type="number"
                step="0.01"
                placeholder={currentPrice}
                value={formData.type === 'market' ? currentPrice : formData.price}
                onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                className={`bg-trading-bg border-trading-border text-white mt-1 ${
                  errors.price ? 'border-trading-sell' : ''
                }`}
                disabled={orderMutation.isPending || formData.type === 'market'}
              />
              {errors.price && (
                <p className="text-xs text-trading-sell mt-1">{errors.price}</p>
              )}
            </div>
          </div>

          {/* Order Type */}
          <div>
            <Label className="text-sm text-trading-text-secondary">Order Type</Label>
            <Select
              value={formData.type}
              onValueChange={(value: any) => setFormData(prev => ({ ...prev, type: value }))}
              disabled={orderMutation.isPending}
            >
              <SelectTrigger className="bg-trading-bg border-trading-border text-white mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-trading-panel border-trading-border">
                <SelectItem value="market">Market Order</SelectItem>
                <SelectItem value="limit">Limit Order</SelectItem>
                <SelectItem value="stop">Stop Order</SelectItem>
                <SelectItem value="stop-limit">Stop Limit</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Order Summary */}
          <div className="bg-trading-bg rounded p-3 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-trading-text-secondary">Total</span>
              <span className="text-white font-medium">${calculateTotal()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-trading-text-secondary">Fee (0.1%)</span>
              <span className="text-white">${(parseFloat(calculateTotal()) * 0.001).toFixed(2)}</span>
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="flex space-x-3 pt-4">
            <Button
              type="submit"
              className={`flex-1 py-2 font-medium ${
                formData.side === 'buy'
                  ? 'bg-trading-buy hover:bg-trading-buy hover:opacity-80 text-white'
                  : 'bg-trading-sell hover:bg-trading-sell hover:opacity-80 text-white'
              }`}
              disabled={orderMutation.isPending}
            >
              {orderMutation.isPending 
                ? 'Placing...' 
                : `Place ${formData.side.toUpperCase()} Order`
              }
            </Button>
            <Button
              type="button"
              variant="outline"
              className="px-4 py-2 border-trading-border hover:bg-trading-border text-trading-text"
              onClick={handleClose}
              disabled={orderMutation.isPending}
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
