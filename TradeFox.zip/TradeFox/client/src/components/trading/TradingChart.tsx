import { useEffect, useRef, useState } from 'react';
import { createChart, IChartApi, ISeriesApi, ColorType } from 'lightweight-charts';
import { convertCandleData } from '@/lib/tradingData';
import { useCandles } from '@/hooks/useTradingData';
import { CandleData, TimeFrame, ChartType } from '@/types/trading';
import { IndicatorConfig, calculateIndicator } from '@/lib/indicators';
import { Loader2 } from 'lucide-react';

interface TradingChartProps {
  symbol: string;
  timeframe: TimeFrame;
  chartType: ChartType;
  indicators?: IndicatorConfig[];
  onPriceUpdate?: (price: number) => void;
}

export default function TradingChart({ 
  symbol, 
  timeframe, 
  chartType,
  indicators = [],
  onPriceUpdate 
}: TradingChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<any> | null>(null);
  const indicatorSeriesRef = useRef<Map<string, ISeriesApi<any>>>(new Map());
  const [isLoading, setIsLoading] = useState(true);

  const { data: candleData, isLoading: isCandleLoading, error } = useCandles(symbol, timeframe);

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: chartContainerRef.current.clientHeight,
      layout: {
        background: { type: ColorType.Solid, color: '#131722' },
        textColor: '#D1D4DC',
      },
      grid: {
        vertLines: { color: '#2A2E39' },
        horzLines: { color: '#2A2E39' },
      },
      crosshair: {
        mode: 1, // Normal crosshair mode
      },
      rightPriceScale: {
        borderColor: '#2A2E39',
        scaleMargins: {
          top: 0.1,
          bottom: 0.1,
        },
      },
      timeScale: {
        borderColor: '#2A2E39',
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
      },
      handleScale: {
        axisPressedMouseMove: true,
        mouseWheel: true,
        pinch: true,
      },
    });

    chartRef.current = chart;

    // Handle resize
    const handleResize = () => {
      if (chartContainerRef.current && chart) {
        chart.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: chartContainerRef.current.clientHeight,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      chart.remove();
    };
  }, []);

  // Update chart type and series
  useEffect(() => {
    if (!chartRef.current) return;

    // Remove existing series
    if (seriesRef.current) {
      chartRef.current.removeSeries(seriesRef.current);
    }

    // Create new series based on chart type
    if (chartType === 'candlestick') {
      seriesRef.current = chartRef.current.addCandlestickSeries({
        upColor: '#00C896',
        downColor: '#FF4747',
        borderDownColor: '#FF4747',
        borderUpColor: '#00C896',
        wickDownColor: '#FF4747',
        wickUpColor: '#00C896',
      });
    } else if (chartType === 'line') {
      seriesRef.current = chartRef.current.addLineSeries({
        color: '#2962FF',
        lineWidth: 2,
      });
    }

    // Set data if available
    if (candleData && seriesRef.current) {
      const convertedData = convertCandleData(candleData);
      
      if (chartType === 'candlestick') {
        seriesRef.current.setData(convertedData);
      } else if (chartType === 'line') {
        const lineData = convertedData.map(candle => ({
          time: candle.time,
          value: candle.close,
        }));
        seriesRef.current.setData(lineData);
      }

      // Update price
      if (convertedData.length > 0) {
        const latestPrice = convertedData[convertedData.length - 1].close;
        onPriceUpdate?.(latestPrice);
      }

      setIsLoading(false);
    }
  }, [chartType, candleData, onPriceUpdate]);

  // Update indicators
  useEffect(() => {
    if (!chartRef.current || !candleData || candleData.length === 0) return;

    // Clear existing indicator series
    indicatorSeriesRef.current.forEach((series) => {
      chartRef.current?.removeSeries(series);
    });
    indicatorSeriesRef.current.clear();

    // Add new indicator series
    indicators.forEach((indicator) => {
      if (!indicator.visible) return;

      try {
        const indicatorData = calculateIndicator(indicator.type, candleData, indicator.parameters);
        
        if (Array.isArray(indicatorData) && indicatorData.length > 0) {
          // Simple line indicators (SMA, EMA, RSI, etc.)
          const lineSeries = chartRef.current!.addLineSeries({
            color: indicator.style.color,
            lineWidth: indicator.style.lineWidth,
            lineStyle: indicator.style.lineStyle === 'dashed' ? 1 : 0,
            title: indicator.name,
          });
          
          lineSeries.setData(indicatorData);
          indicatorSeriesRef.current.set(indicator.id, lineSeries);
        } else if (typeof indicatorData === 'object' && indicatorData !== null) {
          // Complex indicators (MACD, Bollinger Bands, etc.)
          if (indicator.type === 'MACD') {
            const { macd, signal, histogram } = indicatorData as any;
            
            // MACD line
            const macdSeries = chartRef.current!.addLineSeries({
              color: indicator.style.color,
              lineWidth: indicator.style.lineWidth,
              title: `${indicator.name} - MACD`,
            });
            macdSeries.setData(macd);
            indicatorSeriesRef.current.set(`${indicator.id}-macd`, macdSeries);
            
            // Signal line
            const signalSeries = chartRef.current!.addLineSeries({
              color: '#FF6D00',
              lineWidth: indicator.style.lineWidth,
              title: `${indicator.name} - Signal`,
            });
            signalSeries.setData(signal);
            indicatorSeriesRef.current.set(`${indicator.id}-signal`, signalSeries);
            
            // Histogram (as line for simplicity)
            const histogramSeries = chartRef.current!.addLineSeries({
              color: '#666',
              lineWidth: 1,
              title: `${indicator.name} - Histogram`,
            });
            histogramSeries.setData(histogram);
            indicatorSeriesRef.current.set(`${indicator.id}-histogram`, histogramSeries);
          } else if (indicator.type === 'BB') {
            const { upper, middle, lower } = indicatorData as any;
            
            // Upper band
            const upperSeries = chartRef.current!.addLineSeries({
              color: indicator.style.color,
              lineWidth: indicator.style.lineWidth,
              title: `${indicator.name} - Upper`,
            });
            upperSeries.setData(upper);
            indicatorSeriesRef.current.set(`${indicator.id}-upper`, upperSeries);
            
            // Middle band
            const middleSeries = chartRef.current!.addLineSeries({
              color: indicator.style.color,
              lineWidth: indicator.style.lineWidth,
              title: `${indicator.name} - Middle`,
            });
            middleSeries.setData(middle);
            indicatorSeriesRef.current.set(`${indicator.id}-middle`, middleSeries);
            
            // Lower band
            const lowerSeries = chartRef.current!.addLineSeries({
              color: indicator.style.color,
              lineWidth: indicator.style.lineWidth,
              title: `${indicator.name} - Lower`,
            });
            lowerSeries.setData(lower);
            indicatorSeriesRef.current.set(`${indicator.id}-lower`, lowerSeries);
          } else if (indicator.type === 'STOCH') {
            const { k, d } = indicatorData as any;
            
            // %K line
            const kSeries = chartRef.current!.addLineSeries({
              color: indicator.style.color,
              lineWidth: indicator.style.lineWidth,
              title: `${indicator.name} - %K`,
            });
            kSeries.setData(k);
            indicatorSeriesRef.current.set(`${indicator.id}-k`, kSeries);
            
            // %D line
            const dSeries = chartRef.current!.addLineSeries({
              color: '#FF6D00',
              lineWidth: indicator.style.lineWidth,
              title: `${indicator.name} - %D`,
            });
            dSeries.setData(d);
            indicatorSeriesRef.current.set(`${indicator.id}-d`, dSeries);
          }
        }
      } catch (error) {
        console.warn(`Failed to calculate indicator ${indicator.type}:`, error);
      }
    });
  }, [indicators, candleData]);

  // Show loading state
  if (isCandleLoading || isLoading) {
    return (
      <div className="flex-1 bg-trading-bg relative flex items-center justify-center">
        <div className="flex items-center space-x-2 text-trading-text">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span className="text-sm">Loading chart data...</span>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="flex-1 bg-trading-bg relative flex items-center justify-center">
        <div className="text-trading-text-secondary text-sm">
          Failed to load chart data
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-trading-bg relative">
      <div ref={chartContainerRef} className="w-full h-full" />
    </div>
  );
}
