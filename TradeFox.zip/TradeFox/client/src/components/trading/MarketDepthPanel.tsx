import { useMarketDepth, useRecentTrades, useNews } from '@/hooks/useTradingData';
import { formatPrice, formatTime, formatTimeAgo, getPriceChangeColor } from '@/lib/tradingData';
import { Loader2 } from 'lucide-react';

interface MarketDepthPanelProps {
  symbol: string;
  currentPrice: string;
}

export default function MarketDepthPanel({ symbol, currentPrice }: MarketDepthPanelProps) {
  const { data: marketDepth, isLoading: isDepthLoading } = useMarketDepth(symbol);
  const { data: recentTrades, isLoading: isTradesLoading } = useRecentTrades(symbol, 20);
  const { data: news, isLoading: isNewsLoading } = useNews(symbol, 5);

  return (
    <div className="w-80 bg-trading-panel border-l border-trading-border flex flex-col">
      {/* Market Depth */}
      <div className="border-b border-trading-border p-3">
        <h3 className="font-semibold text-sm mb-3 text-white">Market Depth</h3>
        
        {isDepthLoading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="w-4 h-4 animate-spin text-trading-text-secondary" />
          </div>
        ) : marketDepth ? (
          <div className="space-y-1">
            {/* Sell Orders (Asks) */}
            <div className="text-xs text-trading-text-secondary mb-1">Asks</div>
            {marketDepth.asks.slice(0, 5).map((ask, index) => {
              const totalVolume = marketDepth.asks.slice(0, index + 1).reduce(
                (sum, item) => sum + parseFloat(item.quantity), 0
              );
              const maxVolume = Math.max(
                ...marketDepth.asks.slice(0, 5).map(item => parseFloat(item.quantity))
              );
              const widthPercent = (parseFloat(ask.quantity) / maxVolume) * 100;

              return (
                <div key={index} className="flex justify-between items-center py-0.5 text-xs">
                  <span className="text-trading-sell font-mono">
                    {formatPrice(ask.price, 2)}
                  </span>
                  <span className="text-trading-text-secondary font-mono">
                    {parseFloat(ask.quantity).toFixed(5)}
                  </span>
                  <div className="w-16 h-2 bg-trading-sell bg-opacity-20 rounded-sm">
                    <div 
                      className="h-full bg-trading-sell bg-opacity-40 rounded-sm"
                      style={{ width: `${widthPercent}%` }}
                    />
                  </div>
                </div>
              );
            })}
            
            {/* Current Price */}
            <div className="flex justify-center py-2 border-t border-b border-trading-border my-2">
              <span className="text-lg font-bold text-trading-buy">
                {formatPrice(currentPrice, 2)}
              </span>
            </div>
            
            {/* Buy Orders (Bids) */}
            <div className="text-xs text-trading-text-secondary mb-1">Bids</div>
            {marketDepth.bids.slice(0, 5).map((bid, index) => {
              const maxVolume = Math.max(
                ...marketDepth.bids.slice(0, 5).map(item => parseFloat(item.quantity))
              );
              const widthPercent = (parseFloat(bid.quantity) / maxVolume) * 100;

              return (
                <div key={index} className="flex justify-between items-center py-0.5 text-xs">
                  <div className="w-16 h-2 bg-trading-buy bg-opacity-20 rounded-sm">
                    <div 
                      className="h-full bg-trading-buy bg-opacity-40 rounded-sm"
                      style={{ width: `${widthPercent}%` }}
                    />
                  </div>
                  <span className="text-trading-text-secondary font-mono">
                    {parseFloat(bid.quantity).toFixed(5)}
                  </span>
                  <span className="text-trading-buy font-mono">
                    {formatPrice(bid.price, 2)}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-trading-text-secondary text-xs text-center py-4">
            No market depth data
          </div>
        )}
      </div>

      {/* Recent Trades */}
      <div className="border-b border-trading-border p-3 flex-1">
        <h3 className="font-semibold text-sm mb-3 text-white">Recent Trades</h3>
        
        {isTradesLoading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="w-4 h-4 animate-spin text-trading-text-secondary" />
          </div>
        ) : recentTrades && recentTrades.length > 0 ? (
          <div className="space-y-1 overflow-y-auto max-h-40">
            {recentTrades.slice(0, 15).map((trade) => (
              <div key={trade.id} className="flex justify-between items-center text-xs">
                <span className={`font-mono ${trade.side === 'buy' ? 'text-trading-buy' : 'text-trading-sell'}`}>
                  {formatPrice(trade.price, 2)}
                </span>
                <span className="text-trading-text-secondary font-mono">
                  {parseFloat(trade.quantity).toFixed(5)}
                </span>
                <span className="text-trading-text-secondary">
                  {formatTime(trade.timestamp)}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-trading-text-secondary text-xs text-center py-4">
            No recent trades
          </div>
        )}
      </div>

      {/* News Feed */}
      <div className="p-3 flex-1">
        <h3 className="font-semibold text-sm mb-3 text-white">Market News</h3>
        
        {isNewsLoading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="w-4 h-4 animate-spin text-trading-text-secondary" />
          </div>
        ) : news && news.length > 0 ? (
          <div className="space-y-3 overflow-y-auto max-h-48">
            {news.map((newsItem) => (
              <div 
                key={newsItem.id} 
                className="border border-trading-border rounded p-2 hover:bg-trading-bg cursor-pointer transition-colors"
              >
                <h4 className="text-xs font-medium mb-1 text-white line-clamp-2">
                  {newsItem.title}
                </h4>
                <p className="text-xs text-trading-text-secondary mb-1 line-clamp-2">
                  {newsItem.content}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-trading-text-secondary">
                    {formatTimeAgo(newsItem.publishedAt)}
                  </span>
                  <span className="text-xs text-trading-accent">
                    {newsItem.source}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-trading-text-secondary text-xs text-center py-4">
            No news available
          </div>
        )}
      </div>
    </div>
  );
}
