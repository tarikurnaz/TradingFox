import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X, Plus, Settings, Eye, EyeOff } from 'lucide-react';
import { IndicatorType, IndicatorConfig, defaultIndicatorConfigs } from '@/lib/indicators';

interface IndicatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeIndicators: IndicatorConfig[];
  onAddIndicator: (config: IndicatorConfig) => void;
  onUpdateIndicator: (config: IndicatorConfig) => void;
  onRemoveIndicator: (id: string) => void;
}

const indicatorCategories = {
  'Trend': ['SMA', 'EMA', 'BB'] as IndicatorType[],
  'Momentum': ['RSI', 'MACD', 'STOCH', 'WILLIAMS', 'CCI'] as IndicatorType[],
  'Volatility': ['ATR', 'BB'] as IndicatorType[],
  'Volume': ['VOLUME', 'OBV'] as IndicatorType[],
};

export default function IndicatorModal({
  isOpen,
  onClose,
  activeIndicators,
  onAddIndicator,
  onUpdateIndicator,
  onRemoveIndicator,
}: IndicatorModalProps) {
  const [selectedCategory, setSelectedCategory] = useState<keyof typeof indicatorCategories>('Trend');
  const [selectedIndicator, setSelectedIndicator] = useState<IndicatorType | null>(null);
  const [editingIndicator, setEditingIndicator] = useState<IndicatorConfig | null>(null);

  const handleAddIndicator = (type: IndicatorType) => {
    const config = defaultIndicatorConfigs[type];
    const newIndicator: IndicatorConfig = {
      ...config,
      id: `${type}-${Date.now()}`,
    };
    onAddIndicator(newIndicator);
  };

  const handleUpdateIndicator = (indicator: IndicatorConfig, updates: Partial<IndicatorConfig>) => {
    const updatedIndicator = { ...indicator, ...updates };
    onUpdateIndicator(updatedIndicator);
    setEditingIndicator(null);
  };

  const renderParameterInputs = (indicator: IndicatorConfig) => {
    const { parameters } = indicator;
    
    return (
      <div className="space-y-3">
        {Object.entries(parameters).map(([key, value]) => (
          <div key={key} className="flex items-center space-x-2">
            <Label className="text-xs text-trading-text-secondary w-20 capitalize">
              {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
            </Label>
            <Input
              type="number"
              value={value}
              onChange={(e) => {
                const newParams = { ...parameters, [key]: parseInt(e.target.value) };
                handleUpdateIndicator(indicator, { parameters: newParams });
              }}
              className="bg-trading-bg border-trading-border text-white h-7 text-xs w-16"
            />
          </div>
        ))}
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-trading-panel border-trading-border max-w-4xl p-0">
        <DialogHeader className="p-6 pb-4">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold text-white">Technical Indicators</DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              className="p-1 h-6 w-6 text-trading-text-secondary hover:text-trading-text"
              onClick={onClose}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="px-6 pb-6">
          <div className="grid grid-cols-3 gap-6">
            {/* Left Panel - Categories */}
            <div className="space-y-4">
              <h3 className="font-medium text-white text-sm">Categories</h3>
              <div className="space-y-1">
                {Object.keys(indicatorCategories).map((category) => (
                  <Button
                    key={category}
                    variant="ghost"
                    className={`w-full justify-start text-sm h-8 ${
                      selectedCategory === category
                        ? 'bg-trading-accent text-white'
                        : 'hover:bg-trading-bg text-trading-text'
                    }`}
                    onClick={() => setSelectedCategory(category as keyof typeof indicatorCategories)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>

            {/* Middle Panel - Available Indicators */}
            <div className="space-y-4">
              <h3 className="font-medium text-white text-sm">Available Indicators</h3>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {indicatorCategories[selectedCategory].map((type) => {
                  const config = defaultIndicatorConfigs[type];
                  const isActive = activeIndicators.some(ind => ind.type === type);
                  
                  return (
                    <div
                      key={type}
                      className="p-3 bg-trading-bg rounded border border-trading-border hover:border-trading-accent transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-white text-sm">{config.name}</h4>
                          <p className="text-xs text-trading-text-secondary mt-1">
                            {type}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          className={`h-6 px-2 text-xs ${
                            isActive
                              ? 'bg-trading-accent text-white'
                              : 'bg-trading-buy hover:bg-trading-buy hover:opacity-80 text-white'
                          }`}
                          onClick={() => handleAddIndicator(type)}
                          disabled={isActive}
                        >
                          <Plus className="w-3 h-3 mr-1" />
                          {isActive ? 'Added' : 'Add'}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right Panel - Active Indicators */}
            <div className="space-y-4">
              <h3 className="font-medium text-white text-sm">
                Active Indicators ({activeIndicators.length})
              </h3>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {activeIndicators.length === 0 ? (
                  <div className="text-center py-8 text-trading-text-secondary text-sm">
                    No indicators added yet
                  </div>
                ) : (
                  activeIndicators.map((indicator) => (
                    <div
                      key={indicator.id}
                      className="p-3 bg-trading-bg rounded border border-trading-border"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <div
                            className="w-3 h-3 rounded"
                            style={{ backgroundColor: indicator.style.color }}
                          />
                          <span className="font-medium text-white text-sm">
                            {indicator.name}
                          </span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="p-1 h-6 w-6 text-trading-text-secondary hover:text-trading-text"
                            onClick={() => handleUpdateIndicator(indicator, { visible: !indicator.visible })}
                          >
                            {indicator.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="p-1 h-6 w-6 text-trading-text-secondary hover:text-trading-text"
                            onClick={() => setEditingIndicator(editingIndicator?.id === indicator.id ? null : indicator)}
                          >
                            <Settings className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="p-1 h-6 w-6 text-trading-sell hover:text-trading-sell"
                            onClick={() => onRemoveIndicator(indicator.id)}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      {editingIndicator?.id === indicator.id && (
                        <div className="border-t border-trading-border pt-2 mt-2">
                          {renderParameterInputs(indicator)}
                          
                          <div className="mt-3">
                            <Label className="text-xs text-trading-text-secondary">Color</Label>
                            <div className="flex items-center space-x-2 mt-1">
                              <input
                                type="color"
                                value={indicator.style.color}
                                onChange={(e) => handleUpdateIndicator(indicator, {
                                  style: { ...indicator.style, color: e.target.value }
                                })}
                                className="w-8 h-6 rounded border border-trading-border bg-trading-bg"
                              />
                              <Input
                                value={indicator.style.color}
                                onChange={(e) => handleUpdateIndicator(indicator, {
                                  style: { ...indicator.style, color: e.target.value }
                                })}
                                className="bg-trading-bg border-trading-border text-white h-6 text-xs flex-1"
                              />
                            </div>
                          </div>

                          <div className="mt-3">
                            <Label className="text-xs text-trading-text-secondary">Line Width</Label>
                            <Input
                              type="number"
                              min="1"
                              max="5"
                              value={indicator.style.lineWidth}
                              onChange={(e) => handleUpdateIndicator(indicator, {
                                style: { ...indicator.style, lineWidth: parseInt(e.target.value) }
                              })}
                              className="bg-trading-bg border-trading-border text-white h-6 text-xs w-16 mt-1"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}