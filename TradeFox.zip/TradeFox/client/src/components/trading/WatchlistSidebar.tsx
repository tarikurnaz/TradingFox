import { useState } from 'react';
import { Plus, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useSymbols } from '@/hooks/useTradingData';
import { formatPrice, formatPercentage, getPriceChangeColor } from '@/lib/tradingData';
import { TradingSymbol } from '@/types/trading';

interface WatchlistSidebarProps {
  onSymbolSelect: (symbol: string) => void;
  selectedSymbol: string;
}

export default function WatchlistSidebar({ onSymbolSelect, selectedSymbol }: WatchlistSidebarProps) {
  const [selectedCategory, setSelectedCategory] = useState<'crypto' | 'stock' | 'forex'>('crypto');
  const { data: symbols, isLoading } = useSymbols();

  const filteredSymbols = symbols?.filter(symbol => symbol.type === selectedCategory) || [];

  const handleSymbolClick = (symbol: TradingSymbol) => {
    onSymbolSelect(symbol.symbol);
  };

  return (
    <div className="w-64 bg-trading-panel border-r border-trading-border flex flex-col">
      {/* Watchlist Header */}
      <div className="p-3 border-b border-trading-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm text-white">Watchlist</h3>
          <div className="flex items-center space-x-2">
            <Button
              size="sm"
              variant="ghost"
              className="p-1 h-6 w-6 text-trading-text-secondary hover:text-trading-text"
            >
              <Plus className="w-3 h-3" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="p-1 h-6 w-6 text-trading-text-secondary hover:text-trading-text"
            >
              <Settings className="w-3 h-3" />
            </Button>
          </div>
        </div>
        
        {/* Category Tabs */}
        <div className="flex mt-2 text-xs space-x-1">
          <Button
            size="sm"
            variant="ghost"
            className={`px-2 py-1 h-6 ${
              selectedCategory === 'crypto' 
                ? 'bg-trading-accent text-white' 
                : 'hover:bg-trading-border text-trading-text'
            }`}
            onClick={() => setSelectedCategory('crypto')}
          >
            Crypto
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={`px-2 py-1 h-6 ${
              selectedCategory === 'stock' 
                ? 'bg-trading-accent text-white' 
                : 'hover:bg-trading-border text-trading-text'
            }`}
            onClick={() => setSelectedCategory('stock')}
          >
            Stocks
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={`px-2 py-1 h-6 ${
              selectedCategory === 'forex' 
                ? 'bg-trading-accent text-white' 
                : 'hover:bg-trading-border text-trading-text'
            }`}
            onClick={() => setSelectedCategory('forex')}
          >
            Forex
          </Button>
        </div>
      </div>
      
      {/* Watchlist Items */}
      <div className="flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="p-3 text-center text-trading-text-secondary text-sm">
            Loading symbols...
          </div>
        ) : filteredSymbols.length === 0 ? (
          <div className="p-3 text-center text-trading-text-secondary text-sm">
            No symbols available
          </div>
        ) : (
          filteredSymbols.map((symbol) => (
            <div
              key={symbol.id}
              className={`px-3 py-2 border-b border-trading-border hover:bg-trading-bg cursor-pointer transition-colors ${
                selectedSymbol === symbol.symbol ? 'bg-trading-bg' : ''
              }`}
              onClick={() => handleSymbolClick(symbol)}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm text-white truncate">
                    {symbol.symbol}
                  </div>
                  <div className="text-xs text-trading-text-secondary truncate">
                    {symbol.name}
                  </div>
                </div>
                <div className="text-right ml-2">
                  <div className="text-sm font-medium text-white">
                    ${formatPrice(symbol.price, symbol.type === 'forex' ? 4 : 2)}
                  </div>
                  <div className={`text-xs ${getPriceChangeColor(symbol.change24h)}`}>
                    {formatPercentage(symbol.change24h)}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
