import { useQuery } from '@tanstack/react-query';
import { TradingSymbol, MarketDepthData, RecentTrade, NewsItem, TradingOrder, Position } from '@/types/trading';

export function useSymbols() {
  return useQuery<TradingSymbol[]>({
    queryKey: ['/api/symbols'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });
}

export function useSymbol(symbol: string) {
  return useQuery<TradingSymbol>({
    queryKey: ['/api/symbols', symbol],
    enabled: !!symbol,
    refetchInterval: 5000, // Refetch every 5 seconds
  });
}

export function useCandles(symbol: string, timeframe: string, limit = 300) {
  return useQuery({
    queryKey: ['/api/candles', symbol, timeframe, limit],
    enabled: !!symbol && !!timeframe,
    refetchInterval: timeframe === '1m' ? 10000 : timeframe === '5m' ? 30000 : 60000,
  });
}

export function useMarketDepth(symbol: string) {
  return useQuery<MarketDepthData>({
    queryKey: ['/api/depth', symbol],
    enabled: !!symbol,
    refetchInterval: 2000, // Refetch every 2 seconds
  });
}

export function useRecentTrades(symbol: string, limit = 50) {
  return useQuery<RecentTrade[]>({
    queryKey: ['/api/trades', symbol, limit],
    enabled: !!symbol,
    refetchInterval: 3000, // Refetch every 3 seconds
  });
}

export function useNews(symbol?: string, limit = 20) {
  return useQuery<NewsItem[]>({
    queryKey: ['/api/news', symbol, limit],
    refetchInterval: 60000, // Refetch every minute
  });
}

export function useOrders() {
  return useQuery<TradingOrder[]>({
    queryKey: ['/api/orders'],
    refetchInterval: 5000, // Refetch every 5 seconds
  });
}

export function usePositions() {
  return useQuery<Position[]>({
    queryKey: ['/api/positions'],
    refetchInterval: 5000, // Refetch every 5 seconds
  });
}

export function useWatchlist() {
  return useQuery({
    queryKey: ['/api/watchlist'],
    refetchInterval: 10000, // Refetch every 10 seconds
  });
}

// Mock account data - in real app this would come from API
export function useAccountData() {
  return {
    data: {
      balance: '12,450.75',
      equity: '12,580.32',
      freeMargin: '8,420.18',
      marginLevel: '302.5',
      pnl: '+129.57',
      todayPnl: '+87.23',
    },
    isLoading: false,
    error: null,
  };
}
