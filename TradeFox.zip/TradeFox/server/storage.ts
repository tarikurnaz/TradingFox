import {
  type User,
  type InsertUser,
  type Symbol,
  type InsertSymbol,
  type Watchlist,
  type InsertWatchlist,
  type Order,
  type InsertOrder,
  type Position,
  type InsertPosition,
  type Candle,
  type InsertCandle,
  type MarketDepth,
  type InsertMarketDepth,
  type Trade,
  type InsertTrade,
  type News,
  type InsertNews,
  users,
  symbols,
  watchlists,
  orders,
  positions,
  candles,
  marketDepth,
  trades,
  news
} from "@shared/schema";
import { db } from './db';
import { eq, desc, and, gte, asc } from 'drizzle-orm';
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Symbol methods
  getSymbols(): Promise<Symbol[]>;
  getSymbol(symbol: string): Promise<Symbol | undefined>;
  createSymbol(symbol: InsertSymbol): Promise<Symbol>;
  updateSymbolPrice(symbol: string, price: string, change24h: string): Promise<void>;

  // Watchlist methods
  getUserWatchlists(userId: string): Promise<Watchlist[]>;
  createWatchlist(watchlist: InsertWatchlist): Promise<Watchlist>;
  updateWatchlist(id: string, symbols: string[]): Promise<void>;

  // Order methods
  getUserOrders(userId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<void>;

  // Position methods
  getUserPositions(userId: string): Promise<Position[]>;
  createPosition(position: InsertPosition): Promise<Position>;
  updatePosition(id: string, quantity: string, unrealizedPnl: string): Promise<void>;

  // Candle methods
  getCandles(symbol: string, timeframe: string, limit?: number): Promise<Candle[]>;
  createCandle(candle: InsertCandle): Promise<Candle>;

  // Market depth methods
  getMarketDepth(symbol: string): Promise<MarketDepth[]>;
  updateMarketDepth(symbol: string, bids: InsertMarketDepth[], asks: InsertMarketDepth[]): Promise<void>;

  // Trade methods
  getRecentTrades(symbol: string, limit?: number): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;

  // News methods
  getNews(symbol?: string, limit?: number): Promise<News[]>;
  createNews(news: InsertNews): Promise<News>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private symbols: Map<string, Symbol> = new Map();
  private watchlists: Map<string, Watchlist> = new Map();
  private orders: Map<string, Order> = new Map();
  private positions: Map<string, Position> = new Map();
  private candles: Map<string, Candle[]> = new Map();
  private marketDepth: Map<string, MarketDepth[]> = new Map();
  private trades: Map<string, Trade[]> = new Map();
  private newsItems: News[] = [];

  constructor() {
    this.initializeMockData();
  }

  private initializeMockData() {
    // Initialize mock symbols
    const mockSymbols = [
      { symbol: 'BTCUSD', name: 'Bitcoin', type: 'crypto', price: '43250.75', change24h: '1.24', volume24h: '1234567890' },
      { symbol: 'ETHUSD', name: 'Ethereum', type: 'crypto', price: '2567.43', change24h: '-0.89', volume24h: '987654321' },
      { symbol: 'AAPL', name: 'Apple Inc', type: 'stock', price: '185.25', change24h: '2.15', volume24h: '45678901' },
      { symbol: 'GOOGL', name: 'Alphabet Inc', type: 'stock', price: '2850.67', change24h: '0.75', volume24h: '23456789' },
      { symbol: 'EURUSD', name: 'Euro/USD', type: 'forex', price: '1.0875', change24h: '-0.12', volume24h: '567890123' },
    ];

    mockSymbols.forEach(symbolData => {
      const symbol: Symbol = {
        id: randomUUID(),
        ...symbolData,
        lastUpdated: new Date(),
      };
      this.symbols.set(symbol.symbol, symbol);
    });

    // Initialize mock market depth
    this.symbols.forEach((symbol) => {
      this.generateMockMarketDepth(symbol.symbol);
      this.generateMockTrades(symbol.symbol);
      this.generateMockCandles(symbol.symbol);
    });

    // Initialize mock news
    const mockNews = [
      {
        title: 'Bitcoin Reaches New Weekly High',
        content: 'Strong buying pressure pushes BTC above key resistance level as institutional interest continues to grow.',
        symbol: 'BTCUSD',
        source: 'CryptoNews',
      },
      {
        title: 'Fed Meeting Minutes Released',
        content: 'Central bank signals potential interest rate adjustments in upcoming policy decisions.',
        symbol: undefined,
        source: 'Financial Times',
      },
      {
        title: 'Apple Announces Q4 Earnings',
        content: 'Tech giant reports strong quarterly results with revenue beating analyst expectations.',
        symbol: 'AAPL',
        source: 'MarketWatch',
      },
    ];

    mockNews.forEach(newsData => {
      const newsItem: News = {
        id: randomUUID(),
        ...newsData,
        symbol: newsData.symbol || null,
        publishedAt: new Date(),
      };
      this.newsItems.push(newsItem);
    });
  }

  private generateMockMarketDepth(symbol: string) {
    const basePrice = parseFloat(this.symbols.get(symbol)?.price || '100');
    const depth: MarketDepth[] = [];

    // Generate bids (buy orders)
    for (let i = 0; i < 10; i++) {
      const price = basePrice - (i + 1) * (basePrice * 0.001);
      depth.push({
        id: randomUUID(),
        symbol,
        side: 'bid',
        price: price.toFixed(8),
        quantity: (Math.random() * 10).toFixed(8),
        timestamp: new Date(),
      });
    }

    // Generate asks (sell orders)
    for (let i = 0; i < 10; i++) {
      const price = basePrice + (i + 1) * (basePrice * 0.001);
      depth.push({
        id: randomUUID(),
        symbol,
        side: 'ask',
        price: price.toFixed(8),
        quantity: (Math.random() * 10).toFixed(8),
        timestamp: new Date(),
      });
    }

    this.marketDepth.set(symbol, depth);
  }

  private generateMockTrades(symbol: string) {
    const basePrice = parseFloat(this.symbols.get(symbol)?.price || '100');
    const trades: Trade[] = [];

    for (let i = 0; i < 50; i++) {
      const price = basePrice + (Math.random() - 0.5) * (basePrice * 0.01);
      trades.push({
        id: randomUUID(),
        symbol,
        price: price.toFixed(8),
        quantity: (Math.random() * 1).toFixed(8),
        side: Math.random() > 0.5 ? 'buy' : 'sell',
        timestamp: new Date(Date.now() - i * 1000 * 60),
      });
    }

    this.trades.set(symbol, trades);
  }

  private generateMockCandles(symbol: string) {
    const basePrice = parseFloat(this.symbols.get(symbol)?.price || '100');
    const timeframes = ['1m', '5m', '15m', '1h', '4h', '1d', '1w'];
    
    timeframes.forEach(timeframe => {
      const candles: Candle[] = [];
      let currentPrice = basePrice;
      const intervals = timeframe === '1m' ? 1440 : timeframe === '5m' ? 288 : timeframe === '15m' ? 96 : 
                       timeframe === '1h' ? 24 : timeframe === '4h' ? 6 : timeframe === '1d' ? 30 : 12;
      
      for (let i = intervals; i > 0; i--) {
        const open = currentPrice;
        const change = (Math.random() - 0.5) * (basePrice * 0.02);
        const close = open + change;
        const high = Math.max(open, close) + Math.random() * (basePrice * 0.01);
        const low = Math.min(open, close) - Math.random() * (basePrice * 0.01);
        
        const multiplier = timeframe === '1m' ? 60000 : timeframe === '5m' ? 300000 : timeframe === '15m' ? 900000 :
                          timeframe === '1h' ? 3600000 : timeframe === '4h' ? 14400000 : timeframe === '1d' ? 86400000 : 604800000;
        
        candles.push({
          id: randomUUID(),
          symbol,
          timeframe,
          timestamp: new Date(Date.now() - i * multiplier),
          open: open.toFixed(8),
          high: high.toFixed(8),
          low: low.toFixed(8),
          close: close.toFixed(8),
          volume: (Math.random() * 1000000).toFixed(8),
        });
        
        currentPrice = close;
      }
      
      const key = `${symbol}-${timeframe}`;
      this.candles.set(key, candles);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = { ...insertUser, id: randomUUID() };
    this.users.set(user.id, user);
    return user;
  }

  // Symbol methods
  async getSymbols(): Promise<Symbol[]> {
    return Array.from(this.symbols.values());
  }

  async getSymbol(symbol: string): Promise<Symbol | undefined> {
    return this.symbols.get(symbol);
  }

  async createSymbol(insertSymbol: InsertSymbol): Promise<Symbol> {
    const symbol: Symbol = { ...insertSymbol, id: randomUUID(), lastUpdated: new Date() };
    this.symbols.set(symbol.symbol, symbol);
    return symbol;
  }

  async updateSymbolPrice(symbol: string, price: string, change24h: string): Promise<void> {
    const existingSymbol = this.symbols.get(symbol);
    if (existingSymbol) {
      existingSymbol.price = price;
      existingSymbol.change24h = change24h;
      existingSymbol.lastUpdated = new Date();
    }
  }

  // Watchlist methods
  async getUserWatchlists(userId: string): Promise<Watchlist[]> {
    return Array.from(this.watchlists.values()).filter(w => w.userId === userId);
  }

  async createWatchlist(insertWatchlist: InsertWatchlist): Promise<Watchlist> {
    const watchlist: Watchlist = { 
      ...insertWatchlist, 
      id: randomUUID(), 
      createdAt: new Date(),
      symbols: insertWatchlist.symbols || []
    };
    this.watchlists.set(watchlist.id, watchlist);
    return watchlist;
  }

  async updateWatchlist(id: string, symbols: string[]): Promise<void> {
    const watchlist = this.watchlists.get(id);
    if (watchlist) {
      watchlist.symbols = symbols;
    }
  }

  // Order methods
  async getUserOrders(userId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(o => o.userId === userId);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const order: Order = { 
      ...insertOrder, 
      id: randomUUID(), 
      status: 'pending', 
      createdAt: new Date(),
      price: insertOrder.price || null
    };
    this.orders.set(order.id, order);
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<void> {
    const order = this.orders.get(id);
    if (order) {
      order.status = status;
    }
  }

  // Position methods
  async getUserPositions(userId: string): Promise<Position[]> {
    return Array.from(this.positions.values()).filter(p => p.userId === userId);
  }

  async createPosition(insertPosition: InsertPosition): Promise<Position> {
    const position: Position = { 
      ...insertPosition, 
      id: randomUUID(), 
      lastUpdated: new Date(),
      userId: insertPosition.userId || null
    };
    this.positions.set(position.id, position);
    return position;
  }

  async updatePosition(id: string, quantity: string, unrealizedPnl: string): Promise<void> {
    const position = this.positions.get(id);
    if (position) {
      position.quantity = quantity;
      position.unrealizedPnl = unrealizedPnl;
      position.lastUpdated = new Date();
    }
  }

  // Candle methods
  async getCandles(symbol: string, timeframe: string, limit = 300): Promise<Candle[]> {
    const key = `${symbol}-${timeframe}`;
    const candles = this.candles.get(key) || [];
    return candles.slice(-limit);
  }

  async createCandle(insertCandle: InsertCandle): Promise<Candle> {
    const candle: Candle = { ...insertCandle, id: randomUUID() };
    const key = `${candle.symbol}-${candle.timeframe}`;
    const existing = this.candles.get(key) || [];
    existing.push(candle);
    this.candles.set(key, existing);
    return candle;
  }

  // Market depth methods
  async getMarketDepth(symbol: string): Promise<MarketDepth[]> {
    return this.marketDepth.get(symbol) || [];
  }

  async updateMarketDepth(symbol: string, bids: InsertMarketDepth[], asks: InsertMarketDepth[]): Promise<void> {
    const depth: MarketDepth[] = [];
    
    bids.forEach(bid => {
      depth.push({ ...bid, id: randomUUID(), timestamp: new Date() });
    });
    
    asks.forEach(ask => {
      depth.push({ ...ask, id: randomUUID(), timestamp: new Date() });
    });
    
    this.marketDepth.set(symbol, depth);
  }

  // Trade methods
  async getRecentTrades(symbol: string, limit = 50): Promise<Trade[]> {
    const trades = this.trades.get(symbol) || [];
    return trades.slice(-limit);
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const trade: Trade = { ...insertTrade, id: randomUUID(), timestamp: new Date() };
    const existing = this.trades.get(trade.symbol) || [];
    existing.push(trade);
    this.trades.set(trade.symbol, existing.slice(-100)); // Keep only last 100 trades
    return trade;
  }

  // News methods
  async getNews(symbol?: string, limit = 20): Promise<News[]> {
    let filtered = this.newsItems;
    if (symbol) {
      filtered = this.newsItems.filter(n => n.symbol === symbol || !n.symbol);
    }
    return filtered.slice(-limit);
  }

  async createNews(insertNews: InsertNews): Promise<News> {
    const news: News = { 
      ...insertNews, 
      id: randomUUID(), 
      publishedAt: new Date(),
      symbol: insertNews.symbol || null
    };
    this.newsItems.push(news);
    return news;
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getSymbols(): Promise<Symbol[]> {
    return await db.select().from(symbols).orderBy(asc(symbols.symbol));
  }

  async getSymbol(symbol: string): Promise<Symbol | undefined> {
    const [result] = await db.select().from(symbols).where(eq(symbols.symbol, symbol));
    return result;
  }

  async createSymbol(insertSymbol: InsertSymbol): Promise<Symbol> {
    const [symbol] = await db.insert(symbols).values(insertSymbol).returning();
    return symbol;
  }

  async updateSymbolPrice(symbol: string, price: string, change24h: string): Promise<void> {
    await db.update(symbols)
      .set({ price, change24h, lastUpdated: new Date() })
      .where(eq(symbols.symbol, symbol));
  }

  async getUserWatchlists(userId: string): Promise<Watchlist[]> {
    return await db.select().from(watchlists).where(eq(watchlists.userId, userId));
  }

  async createWatchlist(insertWatchlist: InsertWatchlist): Promise<Watchlist> {
    const [watchlist] = await db.insert(watchlists).values(insertWatchlist).returning();
    return watchlist;
  }

  async updateWatchlist(id: string, symbolsArray: string[]): Promise<void> {
    await db.update(watchlists)
      .set({ symbols: symbolsArray })
      .where(eq(watchlists.id, id));
  }

  async getUserOrders(userId: string): Promise<Order[]> {
    return await db.select().from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db.insert(orders).values({
      ...insertOrder,
      status: 'pending'
    }).returning();
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<void> {
    await db.update(orders)
      .set({ status })
      .where(eq(orders.id, id));
  }

  async getUserPositions(userId: string): Promise<Position[]> {
    return await db.select().from(positions).where(eq(positions.userId, userId));
  }

  async createPosition(insertPosition: InsertPosition): Promise<Position> {
    const [position] = await db.insert(positions).values(insertPosition).returning();
    return position;
  }

  async updatePosition(id: string, quantity: string, unrealizedPnl: string): Promise<void> {
    await db.update(positions)
      .set({ quantity, unrealizedPnl, lastUpdated: new Date() })
      .where(eq(positions.id, id));
  }

  async getCandles(symbol: string, timeframe: string, limit = 300): Promise<Candle[]> {
    return await db.select().from(candles)
      .where(and(eq(candles.symbol, symbol), eq(candles.timeframe, timeframe)))
      .orderBy(desc(candles.timestamp))
      .limit(limit);
  }

  async createCandle(insertCandle: InsertCandle): Promise<Candle> {
    const [candle] = await db.insert(candles).values(insertCandle).returning();
    return candle;
  }

  async getMarketDepth(symbol: string): Promise<MarketDepth[]> {
    return await db.select().from(marketDepth)
      .where(eq(marketDepth.symbol, symbol))
      .orderBy(desc(marketDepth.price));
  }

  async createMarketDepth(insertMarketDepth: InsertMarketDepth): Promise<MarketDepth> {
    const [depth] = await db.insert(marketDepth).values(insertMarketDepth).returning();
    return depth;
  }

  async getTrades(symbol: string, limit = 50): Promise<Trade[]> {
    return await db.select().from(trades)
      .where(eq(trades.symbol, symbol))
      .orderBy(desc(trades.timestamp))
      .limit(limit);
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const [trade] = await db.insert(trades).values(insertTrade).returning();
    return trade;
  }

  async getNews(symbol?: string, limit = 20): Promise<News[]> {
    if (symbol) {
      return await db.select().from(news)
        .where(eq(news.symbol, symbol))
        .orderBy(desc(news.publishedAt))
        .limit(limit);
    }
    return await db.select().from(news)
      .orderBy(desc(news.publishedAt))
      .limit(limit);
  }

  async createNews(insertNews: InsertNews): Promise<News> {
    const [newsItem] = await db.insert(news).values(insertNews).returning();
    return newsItem;
  }
}

// Use DatabaseStorage for persistent data
export const storage = new DatabaseStorage();
