import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertOrderSchema, insertWatchlistSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time data
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store active WebSocket connections
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('WebSocket client connected');

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        handleWebSocketMessage(ws, data);
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });

    // Send initial data
    sendInitialData(ws);
  });

  // Broadcast real-time updates
  const broadcastUpdate = (type: string, data: any) => {
    const message = JSON.stringify({ type, data });
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };

  // Simulate real-time price updates
  setInterval(async () => {
    const symbols = await storage.getSymbols();
    for (const symbol of symbols) {
      const change = (Math.random() - 0.5) * 0.02; // ±2% change
      const newPrice = (parseFloat(symbol.price) * (1 + change)).toFixed(8);
      const change24h = (Math.random() - 0.5) * 5; // ±5% daily change
      
      await storage.updateSymbolPrice(symbol.symbol, newPrice, change24h.toFixed(4));
      
      // Broadcast price update
      broadcastUpdate('priceUpdate', {
        symbol: symbol.symbol,
        price: newPrice,
        change24h: change24h.toFixed(4),
      });

      // Generate new trade
      const trade = await storage.createTrade({
        symbol: symbol.symbol,
        price: newPrice,
        quantity: (Math.random() * 1).toFixed(8),
        side: Math.random() > 0.5 ? 'buy' : 'sell',
      });

      broadcastUpdate('newTrade', trade);
    }
  }, 2000); // Update every 2 seconds

  async function handleWebSocketMessage(ws: WebSocket, data: any) {
    switch (data.type) {
      case 'subscribe':
        // Handle symbol subscription
        break;
      case 'unsubscribe':
        // Handle symbol unsubscription
        break;
    }
  }

  async function sendInitialData(ws: WebSocket) {
    try {
      const symbols = await storage.getSymbols();
      ws.send(JSON.stringify({ type: 'symbols', data: symbols }));
    } catch (error) {
      console.error('Error sending initial data:', error);
    }
  }

  // API Routes

  // Get all symbols
  app.get("/api/symbols", async (req, res) => {
    try {
      const symbols = await storage.getSymbols();
      res.json(symbols);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch symbols" });
    }
  });

  // Get symbol details
  app.get("/api/symbols/:symbol", async (req, res) => {
    try {
      const symbol = await storage.getSymbol(req.params.symbol);
      if (!symbol) {
        return res.status(404).json({ error: "Symbol not found" });
      }
      res.json(symbol);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch symbol" });
    }
  });

  // Get candlestick data
  app.get("/api/candles/:symbol/:timeframe", async (req, res) => {
    try {
      const { symbol, timeframe } = req.params;
      const limit = parseInt(req.query.limit as string) || 300;
      const candles = await storage.getCandles(symbol, timeframe, limit);
      res.json(candles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch candles" });
    }
  });

  // Get market depth
  app.get("/api/depth/:symbol", async (req, res) => {
    try {
      const depth = await storage.getMarketDepth(req.params.symbol);
      const bids = depth.filter(d => d.side === 'bid').sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
      const asks = depth.filter(d => d.side === 'ask').sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
      
      res.json({ bids, asks });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch market depth" });
    }
  });

  // Get recent trades
  app.get("/api/trades/:symbol", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const trades = await storage.getRecentTrades(req.params.symbol, limit);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trades" });
    }
  });

  // Get news
  app.get("/api/news", async (req, res) => {
    try {
      const symbol = req.query.symbol as string;
      const limit = parseInt(req.query.limit as string) || 20;
      const news = await storage.getNews(symbol, limit);
      res.json(news);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  // Create order
  app.post("/api/orders", async (req, res) => {
    try {
      const validatedOrder = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedOrder);
      
      // Simulate order processing
      setTimeout(async () => {
        await storage.updateOrderStatus(order.id, 'filled');
        broadcastUpdate('orderUpdate', { ...order, status: 'filled' });
      }, 1000);
      
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid order data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create order" });
      }
    }
  });

  // Get user orders (mock user ID for demo)
  app.get("/api/orders", async (req, res) => {
    try {
      const userId = "demo-user"; // In real app, get from session/auth
      const orders = await storage.getUserOrders(userId);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  // Get user positions (mock user ID for demo)
  app.get("/api/positions", async (req, res) => {
    try {
      const userId = "demo-user"; // In real app, get from session/auth
      const positions = await storage.getUserPositions(userId);
      res.json(positions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch positions" });
    }
  });

  // Create/update watchlist
  app.post("/api/watchlist", async (req, res) => {
    try {
      const validatedWatchlist = insertWatchlistSchema.parse({
        ...req.body,
        userId: "demo-user", // Mock user ID
      });
      const watchlist = await storage.createWatchlist(validatedWatchlist);
      res.json(watchlist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid watchlist data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create watchlist" });
      }
    }
  });

  // Get user watchlists
  app.get("/api/watchlist", async (req, res) => {
    try {
      const userId = "demo-user"; // In real app, get from session/auth
      const watchlists = await storage.getUserWatchlists(userId);
      res.json(watchlists);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch watchlists" });
    }
  });

  return httpServer;
}
