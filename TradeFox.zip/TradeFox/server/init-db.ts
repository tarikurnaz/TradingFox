import { db } from './db';
import { symbols, candles, marketDepth, trades, news } from '@shared/schema';

export async function initializeDatabase() {
  try {
    // Check if symbols already exist
    const existingSymbols = await db.select().from(symbols).limit(1);
    if (existingSymbols.length > 0) {
      console.log('Database already initialized with sample data');
      return;
    }

    console.log('Initializing database with sample data...');

    // Insert sample symbols
    const sampleSymbols = [
      {
        symbol: 'BTCUSD',
        name: 'Bitcoin',
        type: 'crypto',
        price: '43250.75',
        change24h: '1.24',
        volume24h: '25847592.45'
      },
      {
        symbol: 'ETHUSD',
        name: 'Ethereum',
        type: 'crypto',
        price: '2847.92',
        change24h: '-0.86',
        volume24h: '12456783.21'
      },
      {
        symbol: 'SOLUSD',
        name: 'Solana',
        type: 'crypto',
        price: '98.47',
        change24h: '2.15',
        volume24h: '1287456.98'
      },
      {
        symbol: 'ADAUSD',
        name: 'Cardano',
        type: 'crypto',
        price: '0.4856',
        change24h: '-1.02',
        volume24h: '847392.15'
      },
      {
        symbol: 'DOTUSD',
        name: 'Polkadot',
        type: 'crypto',
        price: '7.38',
        change24h: '0.74',
        volume24h: '423891.67'
      }
    ];

    await db.insert(symbols).values(sampleSymbols);

    // Generate sample candlestick data for BTCUSD
    const now = new Date();
    const candleData = [];
    let basePrice = 43200;
    
    for (let i = 299; i >= 0; i--) {
      const timestamp = new Date(now.getTime() - (i * 15 * 60 * 1000)); // 15-minute intervals
      const open = basePrice + (Math.random() - 0.5) * 200;
      const close = open + (Math.random() - 0.5) * 300;
      const high = Math.max(open, close) + Math.random() * 100;
      const low = Math.min(open, close) - Math.random() * 100;
      const volume = Math.random() * 1000;

      candleData.push({
        symbol: 'BTCUSD',
        timeframe: '15m',
        timestamp,
        open: open.toString(),
        high: high.toString(),
        low: low.toString(),
        close: close.toString(),
        volume: volume.toString()
      });

      basePrice = close;
    }

    await db.insert(candles).values(candleData);

    // Generate sample market depth data
    const depthData = [];
    const currentPrice = 43250.75;
    
    // Generate bids (below current price)
    for (let i = 1; i <= 10; i++) {
      depthData.push({
        symbol: 'BTCUSD',
        side: 'bid',
        price: (currentPrice - i * 10).toString(),
        quantity: (Math.random() * 5 + 0.1).toFixed(4)
      });
    }
    
    // Generate asks (above current price)
    for (let i = 1; i <= 10; i++) {
      depthData.push({
        symbol: 'BTCUSD',
        side: 'ask',
        price: (currentPrice + i * 10).toString(),
        quantity: (Math.random() * 5 + 0.1).toFixed(4)
      });
    }

    await db.insert(marketDepth).values(depthData);

    // Generate sample trade data
    const tradeData = [];
    for (let i = 0; i < 50; i++) {
      tradeData.push({
        symbol: 'BTCUSD',
        price: (currentPrice + (Math.random() - 0.5) * 100).toString(),
        quantity: (Math.random() * 2 + 0.01).toFixed(4),
        side: Math.random() > 0.5 ? 'buy' : 'sell'
      });
    }

    await db.insert(trades).values(tradeData);

    // Generate sample news data
    const newsData = [
      {
        title: 'Bitcoin Reaches New Monthly High',
        content: 'Bitcoin has surged to a new monthly high as institutional investors continue to show strong interest in the cryptocurrency market.',
        symbol: 'BTCUSD',
        source: 'CryptoNews'
      },
      {
        title: 'Federal Reserve Maintains Interest Rates',
        content: 'The Federal Reserve has decided to maintain current interest rates, citing ongoing economic stability concerns.',
        symbol: null,
        source: 'Financial Times'
      },
      {
        title: 'Ethereum Network Upgrade Scheduled',
        content: 'The Ethereum network is preparing for its next major upgrade, which promises to improve transaction efficiency.',
        symbol: 'ETHUSD',
        source: 'Ethereum Foundation'
      },
      {
        title: 'Market Volatility Expected This Week',
        content: 'Analysts predict increased market volatility due to upcoming economic data releases and earnings reports.',
        symbol: null,
        source: 'Market Watch'
      },
      {
        title: 'Solana Ecosystem Continues to Grow',
        content: 'The Solana blockchain ecosystem has seen significant growth with new DeFi protocols and NFT projects launching.',
        symbol: 'SOLUSD',
        source: 'Solana Labs'
      }
    ];

    await db.insert(news).values(newsData);

    console.log('Database initialized successfully with sample data');
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}